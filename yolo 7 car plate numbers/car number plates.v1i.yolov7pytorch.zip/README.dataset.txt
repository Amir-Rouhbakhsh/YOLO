# car number plates  > 2024-01-04 8:29pm
https://universe.roboflow.com/object-detection-yolov5-xy5ui/car-number-plates-dbw4a

Provided by a Roboflow user
License: CC BY 4.0

