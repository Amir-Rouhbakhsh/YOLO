# face and fingers > 2024-01-03 7:15pm
https://universe.roboflow.com/object-detection-yolov5-xy5ui/face-and-fingers

Provided by a Roboflow user
License: CC BY 4.0

